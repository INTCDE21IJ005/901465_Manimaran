import { Component } from '@angular/core';
import { Http } from '@angular/http';
import { Employee } from '../Employee';
import { EmployeeService } from '../services/employeeservice.service'
import { Router } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  employees: Employee[] = [];

  constructor(private empService: EmployeeService,
    private router: Router) {
  }
  ngOnInit(): void {
    this.empService.getEmployees().subscribe(value => {
      this.employees = value;
    });
  }

  onClick() {
    this.router.navigate(["/add"]);
  }


}
