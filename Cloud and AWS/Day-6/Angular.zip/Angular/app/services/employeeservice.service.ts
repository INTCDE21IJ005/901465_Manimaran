import { Injectable } from '@angular/core';
import { Employee } from '../Employee';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
};
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private appUrl = 'http://localhost:5000/employees';
  constructor(private http: HttpClient) { }

  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.appUrl);
  }
  deleteEmployee(id: number): Observable<Employee> {
    const url = `${this.appUrl}/${id}`;
    return this.http.delete<Employee>(url);
  }
  addEmployee(emp: Employee): Observable<Employee> {
    return this.http.post<Employee>(this.appUrl, emp);
  }
  updateEmployee(emp: Employee): Observable<Employee> {
    const url = `${this.appUrl}/${emp.id}`;
    return this.http.put<Employee>(url, emp);
  }
  getEmployeeById(id: number): Observable<Employee> {
    const url = `${this.appUrl}/${id}`;
    return this.http.get<Employee>(url);
  }
}
