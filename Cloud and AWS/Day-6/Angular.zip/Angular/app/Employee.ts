export interface Employee {
    id: number;
    name: string;
    age: number;
    gender: string;
    salary: number;

}